<?php
session_start();
// proff
// u=USERNAME&p=PASSWD&t=TARGETNAME
//--------------------------------------//
// Last update 29 March, 2018
// CHangelog
// Update Algoritm
// 14 April 2018
// News Update Algorithm
// https://www.instagram.com/instagram/?__a=1 dosen't work (Forbidden 403)

//--------------------------------------//
@ini_set("output_buffering", "Off");
@ini_set('implicit_//flush', 1);
@ini_set('zlib.output_compression', 0);
@ini_set('max_execution_time',120000);
//date_default_timezone_set('Asia/Jakarta');

error_reporting(E_ALL);
header( 'Content-type: text/html; charset=utf-8' );
function NgeSubmitData($username, $password, $target, $delay){
 //   require_once 'cli_colors.php';
//$colors = new Colors();
$_SESSION['username'] = $username;
function SendRequest($url, $post, $post_data, $user_agent, $cookies) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://i.instagram.com/api/v1/'.$url);
    curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    if($post) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    }
    sleep(1);
$fllp_kuki = "kuki_".$_SESSION['username'].".txt";
    if($cookies) {
        curl_setopt($ch, CURLOPT_COOKIEFILE, $fllp_kuki);
    } else {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $fllp_kuki);
    }


    $response = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);


    return array($http, $response);
}

function GenerateGuid() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 65535),
            mt_rand(0, 65535),
            mt_rand(0, 65535),
            mt_rand(16384, 20479),
            mt_rand(32768, 49151),
            mt_rand(0, 65535),
            mt_rand(0, 65535),
            mt_rand(0, 65535));
}


function GenerateSignature($data) {
    return hash_hmac('sha256', $data, 'b4a23f5e39b5929e0666ac5de94c89d1618a2916');
}


function GenerateUserAgent() {
	$resolutions = array('720x1280', '320x480', '480x800', '1024x768', '1280x720', '768x1024', '480x320');
	$versions = array('GT-N7000', 'SM-N9000', 'GT-I9220', 'GT-I9100');
	$dpis = array('120', '160', '320', '240');

	$ver = $versions[array_rand($versions)];
	$dpi = $dpis[array_rand($dpis)];
	$res = $resolutions[array_rand($resolutions)];

	return 'Instagram 4.'.mt_rand(1,2).'.'.mt_rand(0,2).' Android ('.mt_rand(10,11).'/'.mt_rand(1,3).'.'.mt_rand(3,5).'.'.mt_rand(0,5).'; '.$dpi.'; '.$res.'; samsung; '.$ver.'; '.$ver.'; smdkc210; en_US)';
}

function GetPostData($filename) {
    if(!$filename) {
        echo "The image doesn't exist ".$filename;
    } else {
        $post_data = array('device_timestamp' => time(),
                            'photo' => '@'.$filename);
        return $post_data;
    }
}

function cut_str($str, $left, $right) {
	$front = explode($left, $str);
	$returnVar = array();

	foreach($front as $value) {
		if(strpos($value, $right) !== false) {
			$end = explode($right, $value);
			$returnVar[] = $end[0];
		}
	}

	foreach($returnVar as $key => $value) {
		if(substr($value, 0, 9) == '<!DOCTYPE') unset($returnVar[$key]);
	}

	$returnVar = array_values($returnVar);
	return $returnVar;
}

// Set the username and password of the account that you wish to post a photo to
//$username = $username;
//$password = $_POST['p'];

// Set the path to the file that you wish to post.
// This must be jpeg format and it must be a perfect square
$xfilename = 'image.jpg';

// Set the caption for the photo
$xcaption = "...";

// Define the user agent
$xagent = 'Instagram 6.21.2 Android (19/4.4.2; 480dpi; 1152x1920; Meizu; MX4; mx4; mt6595; en_US)';
$agent = GenerateUserAgent();

// Define the GuID
$guid = GenerateGuid();


// Set the devide ID
$device_id = "android-".$guid;

/* LOG IN */
// You must be logged in to the account that you wish to post a photo too
// Set all of the parameters in the string, and then sign it with their API key using SHA-256
$data = '{"device_id":"'.$device_id.'","guid":"'.$guid.'","username":"'.$username.'","password":"'.$password.'","Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"}';
$sig = GenerateSignature($data);
$data = 'signed_body='.$sig.'.'.urlencode($data).'&ig_sig_key_version=4';
$login = SendRequest('accounts/login/', true, $data, $agent, false);


if(strpos($login[1], "Sorry, an error occurred while processing this request.")) {
    echo "Request failed, there's a chance that this proxy/ip is blocked";
} else {
	if(empty($login[1])) {
		echo "Empty response received from the server while trying to login";
	} else {
		// Decode the array that is returned
		$obj = @json_decode($login[1], true);

		if(empty($obj)) {
			echo "Could not decode the response: ";
		} else {
			echo "\nHallo $username!\n";
//-------------------------------------//
$uri = @file_get_contents("http://www.instagram.com/".$target);
if($uri === false){
    //header('Content-Type: application/json');
    echo "{\"status\": \"fail\", \"data\": \"Sorry, this username isn't available.\"}";
    echo "\n";
    }else{
        
$data = cut_str($uri, 'window._sharedData = ', ';</script>');
$read_data = json_decode($data[0], 1);

//$ekstrak_data = preg_match("/window._sharedData =(.*);<\/script>/", $uri, $new_data);
//$retrieve_data = $new_data[0];
//var_dump($retrieve_data);
//$data_siji = explode("window._sharedData = ", $retrieve_data);
//$real_data = explode(";</script>", $data_siji[1]);
//var_dump($real_data[0]);
//$handle = fopen('tmp/'.$target.'_1.config', "w");
//fwrite($handle, "".$real_data[0]);
//fclose($handle);
//$read_data1 = file_get_contents('tmp/'.$target.'_1.config');
//$read_data = json_decode($read_data1,true);
//-------------------------------------//
$targetID = $read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["id"];
$xl_media = $read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["edge_owner_to_timeline_media"]["edges"][0]["node"]["id"];
$xusermedia = $read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["edge_owner_to_timeline_media"]["edges"][0]["node"]["owner"]["id"];
$xlast_media = $xl_media.'_'.$xusermedia;
$next_max_id = null;
$feed = SendRequest('media/'.$xlast_media.'/likers/', false, false, $agent, true);//('friendships/'.$targetID.'/followers/?max_id=', false, false, $agent, true);
$obj = json_decode($feed[1],true);
@$max_id = $obj->next_max_id;
$itung = 1;
$listids = array();
foreach ($obj["users"] as $users) {

                $pk = $users["pk"];
                //echo "pk: ".print_r($pk);
                $listname = $users["username"];
$uri = @file_get_contents("http://www.instagram.com/".$listname);
if($uri === false){
    //header('Content-Type: application/json');
    echo "{\"status\": \"fail\", \"data\": \"Sorry, this username isn't available.\"}";
    echo "\n";
    }else{

$data = cut_str($uri, 'window._sharedData = ', ';</script>');
$read_data = json_decode($data[0], 1);

//$ekstrak_data = preg_match("/window._sharedData =(.*);<\/script>/", $uri, $new_data);
//$retrieve_data = $new_data[0];
//var_dump($retrieve_data);
//$data_siji = explode("window._sharedData = ", $retrieve_data);
//$real_data = explode(";</script>", $data_siji[1]);
//var_dump($real_data[0]);
//$handle = fopen('tmp/'.$listname.'_1.config', "w");
//fwrite($handle, "".$real_data[0]);
//fclose($handle);
//$read_data1 = file_get_contents('tmp/'.$listname.'_1.config');
//$read_data = json_decode($read_data1,true);

$timegmt7 = gmdate("H:i:s",time() +7*3600);
$tgl = date("d");
$bulan = date("m");
$tahun = date("Y");
//-------------------------------------//
if($read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["edge_owner_to_timeline_media"]["count"] == 'null'|| $read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["is_private"] == true){
	echo "[$timegmt7][$listname]Skip follow & comment. (maybe not have post / private)\n";
    //echo $colors->getColoredString("Skip follow & comment. (maybe not have post / private)", "null", "dark_gray") . "\n";

}else{


$l_media = $read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["edge_owner_to_timeline_media"]["edges"][0]["node"]["id"];
$usermedia = $read_data["entry_data"]["ProfilePage"][0]["graphql"]["user"]["edge_owner_to_timeline_media"]["edges"][0]["node"]["owner"]["id"];
$last_media = $l_media.'_'.$usermedia;
$data = '{"user_id":"'.$pk.'"}';
$sig = GenerateSignature($data);
$new_data = 'signed_body='.$sig.'.'.urlencode($data).'&ig_sig_key_version=4';

$follow = SendRequest('friendships/create/'.$pk.'/', true, $new_data, $agent, true);
$obj2 = json_decode($follow[1]);
$sleeptime = $delay/2;
sleep($sleeptime);
			//flush();
			//ob_//flush();
$filecaption = file_get_contents('commentText.txt');
$trim = explode("|", $filecaption);
$kocok = rand(0,count($trim)-1);
$komen = $trim[$kocok];

$komengnya = '@'.$listname. ',' .$komen;
$action = 'like'; //like, unlike
$k_data = '{"comment_text":"'.$komengnya.'", "media_id":"'.$last_media.'"}';
$k_sig = GenerateSignature($k_data);
$k_new_data = 'signed_body='.$k_sig.'.'.urlencode($k_data).'&ig_sig_key_version=4';
$ngelike = SendRequest('media/'.$last_media.'/'.$action.'/', true, $new_data, $agent, true);
$ngekomen = SendRequest('media/'.$last_media.'/comment/', true, $k_new_data, $agent, true);
$merge = $delay/2;
sleep(2+$merge);
if ($obj2->status == "ok")
{
//echo $colors->getColoredString("memfollow, like & comment si @$listname => Sukses | $pk | $komen", "green") . "\n";

echo "[$timegmt7] @$listname => Berhasil | $pk | $komen | [delay selama: $merge]\n";
} else {
//echo $colors->getColoredString("memfollow, like & comment si @$listname => Gagal", "white", "red") . "\n";

echo "[$timegmt7] @$listname => Gagal\n";
}
//echo "\n";
//flush();
//ob_//flush();
}
}
}
}
}
}
}
}
echo
"
===================================================

                 CREATED BY @0xfd
             https://instagr.am/0xfd

===================================================
\n";
echo "username: ";
$username = trim(fgets(STDIN));
$_SESSION['username'] = $username;
//echo "\n";
echo "password: ";
$password = trim(fgets(STDIN));
//echo "\n";
echo "target: ";
$target = trim(fgets(STDIN));
//echo "\n";
//echo "komen: ";
//$komen = trim(fgets(STDIN));
//echo "\n";
echo "delay in sec: ";
$delay = trim(fgets(STDIN));
if($username == "") {
    die ("username cannot be blank!\n");
} elseif($password == "") {
    die ("password cannot be blank!\n");
} elseif($target == "") {
    die ("target cannot be blank!\n");
}  elseif($delay == "") {
    die ("delay cannot be blank!\n");
} else {
    echo "\nLagi eksekusi ..\n";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=";
    sleep(0);
    echo "=";
    sleep(1);
    echo "=\n";
    while (true) {
        NgeSubmitData($username, $password, $target, $delay);
    }
}
?>
